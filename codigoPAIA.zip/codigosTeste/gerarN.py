from gerador_ini import GeraIni

N_experiments = int(input('quantidade de experimentos: ').strip())

for x in range(N_experiments):
    informações = {}
    nome = input('nome do experimento: ')
    ambiente = input('insira o ambiente que vai utilizar: ')
    ambiente.strip()
    informações['enviroment']= ambiente
    parametros = input('insira parametros seguidos de seus valores: ')
    parametros = list(parametros.split())
    for param in range(0,len(parametros),2):
        chave = parametros[param].strip()
        algo = list(map(float,parametros[param+1].split(',')))
        qtd = len(algo)
        informações[chave] = algo
        print(informações[chave])
    print(informações)

    exp = GeraIni(nome,informações)
    exp.criar_N_ini(qtd)

    



