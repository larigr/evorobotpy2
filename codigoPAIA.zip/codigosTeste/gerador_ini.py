import os
nome = 'teste2'
base = {'enviroment':'HopperBulletEnv-v0','maxmsteps':[27,32,23]}
import json

class GeraIni():
    def __init__(self,nome,dicionario):
        self.__nome = nome
        self.__entrada = dicionario
        self.exp = dicionario['enviroment']

        filename= 'ini_tudo.json'
        with open(filename) as data:
            self.__ini_data = json.load(data)

        while True:
            encontrado = self.procura_exp()
            if encontrado:
                break
            self.exp = input('Seu experimento não foi encontrado insira um experimento valido: ')
            self.exp = self.exp.strip()



        
    def procura_exp(self):
        for dic in self.__ini_data:
            if self.exp in dic.keys():
                self.__ini_data = dic
                print(self.__ini_data)
                return True
        return False

    def modificar_dict(self,N=0):
      

        data = self.__ini_data[self.exp]
        for values in data.items():
            values = values[1]
            for key in self.__entrada:
                if key in values:
                    values[key]= self.__entrada[key][N]
        self.ini_feito = data    
        return data 

    def criar_N_ini(self,N):
        os.mkdir(self.__nome)
        for x in range(N):
            self.ini_feito = self.modificar_dict(x)
            self.criar_ini(x)        

    def criar_ini(self,N):
        path = os.path.join(self.__nome,self.__nome+f'{N}.ini')
        with open(path,'w') as inifile:
            inifile.write('[EXP]\n')
            inifile.write(self.exp+str('\n'))
            for key,args in self.ini_feito.items():
                inifile.write(key+"\n")
                for skey,sargs in args.items():
                    linha = skey+" = "+str(sargs)+"\n"
                    inifile.write(linha)
    def criar_exp(self):
        self.modificar_dict()
        self.criar_ini()
if __name__ == '__main__':
    arquivo = GeraIni('t5',base)
    arquivo.criar_N_ini(3) 



